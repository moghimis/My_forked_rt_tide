function y = fp( x,n )
%FP Summary of this function goes here
%   Detailed explanation goes here
    
    y = floor(x*10^n)/10^n;

end

